import RPi.GPIO as GPIO
import telepot
from telepot.loop import MessageLoop
import time

# Pin Constants
BLUE_PIN = 7
RED_PIN = 11
YELLOW_PIN = 13

# Telegram Bot Token
TELEGRAM_BOT_TOKEN = 'Your-Telegram-Bot-Token-Goes-Here'

# Setup GPIO
GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(False)
GPIO.setup(BLUE_PIN, GPIO.OUT)
GPIO.setup(RED_PIN, GPIO.OUT)
GPIO.setup(YELLOW_PIN, GPIO.OUT)

# Telegram Bot Functions
def handle_message(msg):
    chat_id = msg['chat']['id']
    command = msg['text']
    print('Received: %s' % command)

    if 'on' in command:
        turn_on_lights(command)
    elif 'off' in command:
        turn_off_lights(command)

def turn_on_lights(command):
    lights = []
    if 'blue' in command:
        lights.append(BLUE_PIN)
    if 'yellow' in command:
        lights.append(YELLOW_PIN)
    if 'red' in command:
        lights.append(RED_PIN)
    if 'all' in command:
        lights = [BLUE_PIN, YELLOW_PIN, RED_PIN]

    for pin in lights:
        GPIO.output(pin, GPIO.HIGH)

    message = f'on {" ".join(lights)} lights'
    send_telegram_message(message)

def turn_off_lights(command):
    lights = []
    if 'blue' in command:
        lights.append(BLUE_PIN)
    if 'yellow' in command:
        lights.append(YELLOW_PIN)
    if 'red' in command:
        lights.append(RED_PIN)
    if 'all' in command:
        lights = [BLUE_PIN, YELLOW_PIN, RED_PIN]

    for pin in lights:
        GPIO.output(pin, GPIO.LOW)

    message = f'off {" ".join(lights)} lights'
    send_telegram_message(message)

def send_telegram_message(message):
    telegram_bot.sendMessage(chat_id, message)

# Main Program
telegram_bot = telepot.Bot(TELEGRAM_BOT_TOKEN)
print('Up and Running...')

MessageLoop(telegram_bot, handle_message).run_as_thread()

try:
    while True:
        time.sleep(10)
except KeyboardInterrupt:
    print('Shutting down...')
finally:
    GPIO.cleanup()
