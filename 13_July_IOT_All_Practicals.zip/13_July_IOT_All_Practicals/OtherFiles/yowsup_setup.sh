#!/bin/bash

# Step 1: Update system packages
sudo apt-get update
sudo apt-get upgrade

# Step 2: Install dependencies for Yowsup
sudo apt-get install python-dateutil python-setuptools python-dev libevent-dev ncurses-dev

# Step 3: Download and install Yowsup library
git clone git://github.com/tgalal/yowsup.git
cd yowsup
sudo python setup.py install

# Step 4: Register phone number with Yowsup
read -p "Enter your phone number (including country code): " phone_number
read -p "Enter the registration code received via SMS: " registration_code

yowsup-cli registration --requestcode sms --phone $phone_number --cc 39 --mcc 222 --mnc 10
yowsup-cli registration --register $registration_code --phone $phone_number

echo "Yowsup registration completed successfully."

# Step 5: Usage instructions
echo ""
echo "You can now use the Yowsup library to interact with the Telegram API in your Python code."
echo "Refer to the Yowsup documentation and examples for more information on how to use the library."
