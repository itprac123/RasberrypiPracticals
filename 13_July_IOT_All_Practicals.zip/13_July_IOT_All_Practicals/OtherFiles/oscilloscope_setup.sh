#!/bin/bash

# Step 1: Enable I2C interface
sudo raspi-config nonint do_i2c 0

# Step 2: Update system packages
sudo apt-get update
sudo apt-get upgrade

# Step 3: Install required packages
sudo apt-get install python-pip build-essential python-dev python-smbus git

# Step 4: Clone and install Adafruit_python_ADS1x15 library
git clone https://github.com/adafruit/Adafruit_Python_ADS1x15.git
cd Adafruit_Python_ADS1x15
sudo python setup.py install

# Step 5: Install matplotlib and drawnow libraries
sudo apt-get install python-matplotlib
sudo pip install drawnow

echo "Setup completed successfully."

