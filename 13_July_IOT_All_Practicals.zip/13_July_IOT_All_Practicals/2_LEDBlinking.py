import RPi.GPIO as GPIO
import time
GPIO.setmode(GPIO.BOARD)
GPIO.setup(18,GPIO.OUT)
       While(True):
Print(“LED on”)
GPIO.output(18,GPIO.HIGH)
Time.sleep(2)

Print(“LED off”)
GPIO.output(18,GPIO.Low)
Time.sleep(2)
