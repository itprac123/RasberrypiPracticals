import Rpi.GPIO as GPIO
import time
GPIO.setmode(GPIO.BOARD)
GPIO.setup(3,GPIO.OUT)
GPIO.setup(8,GPIO.OUT)
GPIO.setup(12,GPIO.OUT)
GPIO.setup(16,GPIO.OUT)

	While True:
		GPIO.output(3,GPIO.True)
		GPIO.output(12,GPIO.True)
		Time.sleep(0.4)
		GPIO.output(3,GPIO.False)
		GPIO.output(12,GPIO.False)
		time.sleep(0.4)

		GPIO.output(8,GPIO.True)
		GPIO.output(16,GPIO.True)
		Time.sleep(0.4)
		GPIO.output(8,GPIO.False)
		GPIO.output(16,GPIO.False)
		Time.sleep(0.4)

		GPIO.output(3,GPIO.True)
		GPIO.output(16,GPIO.True)
		Time.sleep(0.4)
		GPIO.output(3,GPIO.False)
		GPIO.output(16,GPIO.False)
		time.sleep(0.4)

		GPIO.output(8,GPIO.True)
		GPIO.output(12,GPIO.True)
		Time.sleep(0.4)
		GPIO.output(8,GPIO.False)
		GPIO.output(12,GPIO.False)
		Time.sleep(0.4)
