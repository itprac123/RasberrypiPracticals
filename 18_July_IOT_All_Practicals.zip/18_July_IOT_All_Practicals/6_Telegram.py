import RPi.GPIO as GPIO
import telepot
from telepot.loop import MessageLoop
import time

GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(False)

blue = 7
red = 11
yellow = 13

GPIO.setup(blue, GPIO.OUT)
GPIO.output(blue, False)
GPIO.setup(red, GPIO.OUT)
GPIO.output(red, False)
GPIO.setup(yellow, GPIO.OUT)
GPIO.output(yellow, False)

def action(msg):
    chat_id = msg['chat']['id']
    command = msg['text']
    print('Received: %s' % command)
    message = ''

    if 'on' in command:
        message = 'on'
        if 'blue' in command:
            message += " blue"
            GPIO.output(blue, 1)
        if 'yellow' in command:
            message += " yellow"
            GPIO.output(yellow, 1)
        if 'red' in command:
            message += " red"
            GPIO.output(red, 1)
        if 'all' in command:
            message += " all"
            GPIO.output(blue, 1)
            GPIO.output(yellow, 1)
            GPIO.output(red, 1)
        message += " lights"
        telegram_bot.sendMessage(chat_id, message)

    if 'off' in command:
        message = 'off'
        if 'blue' in command:
            message += " blue"
            GPIO.output(blue, 0)
        if 'yellow' in command:
            message += " yellow"
            GPIO.output(yellow, 0)
        if 'red' in command:
            message += " red"
            GPIO.output(red, 0)
        if 'all' in command:
            message += " all"
            GPIO.output(blue, 0)
            GPIO.output(yellow, 0)
            GPIO.output(red, 0)
        message += " lights"
        telegram_bot.sendMessage(chat_id, message)

telegram_bot = telepot.Bot('Your-Telegram-Bot-Token-Goes-Here')
print('Up and Running….')

MessageLoop(telegram_bot, action).run_as_thread()

while True:
    time.sleep(10)
