import Adafruit_ADS1x15

# Create an instance of the ADS1115 ADC object
adc = Adafruit_ADS1x15.ADS1115()

# Set the gain for the ADC (amplification factor)
GAIN = 1

# Read the ADC value from channel 0
value = adc.read_adc(0, gain=GAIN)

# Print the value read from channel 0
print('Channel 0 {0}'.format(value))
