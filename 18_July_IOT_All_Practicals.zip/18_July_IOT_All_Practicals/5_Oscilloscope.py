"""
Initial Steps:
Step 1: Enable I2C
        Run the following command from the terminal:
        $ sudo raspi-config
        In the configuration panel, select "Interface Options," then select "I2C" and enable it.

Step 2: Update and install dependencies
        $ sudo apt-get update
        $ sudo apt-get upgrade
        $ cd ~
        $ sudo apt-get install build-essential python-dev python-smbus git
        $ cd Adafruit_Python_ADS1x1z
        $ sudo python setup.py install

Step 3: Test the library and I2C communication
        $ cd examples
        Run the sampletest.py example, which displays the value of the four channels on the ADC in a tabular form.
        $ python simpletest.py

Step 4: Install matplotlib for data visualization
        $ sudo apt-get install python-matplotlib

Step 5: Install drawnow for live updates to the data plot
        $ sudo apt-get install python-pip
        $ sudo pip install drawnow
"""

import time
import matplotlib.pyplot as plt
from drawnow import *
import Adafruit_ADS1x15

# Create an instance of the ADS1115 ADC object
adc = Adafruit_ADS1x15.ADS1115()

# Set the gain for the ADC (amplification factor)
GAIN = 1

# Create an empty list to store ADC values
val = []

# Counter variable for the number of values read
cnt = 0

# Turn on interactive mode for matplotlib
plt.ion()

# Start ADC conversion on channel 0 with the specified gain
adc.start_adc(0, gain=GAIN)

# Print a message indicating that channel 0 of the ADC is being read
print("Reading ADS1x15 channel 0")

# Function to create the plot figure
def makeFig():
    plt.ylim(5000, 5000)  # Set the y-axis limits
    plt.title("Oscilloscope")  # Set the title of the plot
    plt.grid(True)  # Enable grid lines
    plt.ylabel("ADC Outputs")  # Set the label for the y-axis
    plt.plot(val, 'ro-', label='lux')  # Plot the ADC values as red dots
    plt.legend(loc="lower right")  # Add a legend to the plot

# Continuous loop for reading ADC values
while True:
    # Read the last ADC conversion result from channel 0
    value = adc.get_last_result()

    # Print the value read from channel 0
    print('Channel 0: {0}'.format(value))

    # Pause for 0.5 seconds
    time.sleep(0.5)

    # Append the value to the list of ADC values
    val.append(int(value))

    # Call the makeFig function to update the plot
    drawnow(makeFig)

    # Pause for a short duration to allow the plot to update
    plt.pause(0.001)

    # Increment the counter variable
    cnt = cnt + 1

    # If the number of values read exceeds 50, remove the oldest value from the list
    if cnt > 50:
        val.pop(0)
